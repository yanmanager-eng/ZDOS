# PATCH-001：Dashboard 安全整理

## 基準檔案
使用目前可正常運作的：
`index_ZDOS_v1_0_2_DASHBOARD.html`

另存為開發版，不要直接覆蓋正式版。

## 目標
只整理 Dashboard 程式區塊，禁止修改登入、業績、庫存、Google Form、員工帳密與 Recovery 邏輯。

## Cursor 指令
請對目前 HTML 執行以下修改：

1. 保留所有現有函式與 localStorage key。
2. 找到註解：
   `// -- VIEW B: ZDOS 今日營運首頁 --`
3. 將 Dashboard 的 HTML 產生區塊包成獨立函式：
   `function renderDashboard(currentMatched, hasInventoryPrivilege, currentStoreRecords, currentStoreInvRecords)`

4. 該函式只回傳 HTML 字串，不可修改 state。
5. `renderApp()` 裡改為：
   `root.innerHTML = renderDashboard(...); return;`
6. 不修改 `handleLoginSubmit`。
7. 不修 BUG-001。
8. 不新增任何第三方套件。
9. 完成後檢查：
   - 所有反引號成對
   - 所有 `${...}` 僅存在於模板字串內
   - JavaScript 無語法錯誤
   - 登入後 Dashboard 可顯示
   - 點營運中心可進業績
   - 點庫存中心可進庫存
   - 返回 ZDOS 首頁正常

## 驗收標準
- 頁面不可白屏。
- 原本 Google Form URL 與 entry ID 不得改動。
- 原本 localStorage key 不得改名。
- 檔案功能表現與 v1.0.2 Dashboard 完全相同。
- 本 Patch 只做結構整理，不增加畫面功能。
