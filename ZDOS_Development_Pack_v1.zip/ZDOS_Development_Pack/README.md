# ZDOS Development Pack

這是 ZDOS 的第一份開發管理底稿。

內容：
- `docs/BUG.md`
- `docs/FEATURE.md`
- `docs/CHANGELOG.md`
- `docs/ROADMAP.md`
- `docs/UI_GUIDE.md`
- `patches/PATCH_001_CURSOR.md`

目前正式基準：
`index_ZDOS_v1_0_2_DASHBOARD.html`
