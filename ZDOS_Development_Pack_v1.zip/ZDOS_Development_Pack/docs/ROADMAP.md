# ZDOS Roadmap

## 現階段：v1.0.x Foundation
- 穩定登入
- 業績回報
- 庫存盤點
- 員工管理
- Google Form
- 備份與還原
- Dashboard

## 下一階段：v1.1
- 完成今日任務 Dashboard
- 修正累積 BUG
- 不加入世界之樹

## 暫存想法
- 世界之樹
- 新人天地
- SOP
- 成就系統
- AI 助理
