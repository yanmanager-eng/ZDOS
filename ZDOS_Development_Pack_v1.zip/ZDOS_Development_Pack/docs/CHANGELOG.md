# ZDOS Changelog

## v1.0.2 Dashboard
- 建立登入後 Dashboard。
- 加入 ZDOS 品牌與中東營運系統名稱。
- 保留登入、業績、庫存、Google Form、員工管理及 Recovery。
- 已知問題：BUG-001。

## v1.0.1 Dashboard
- 建立第一版登入後首頁。
- 新增返回 ZDOS 首頁。
- 建立模組入口。

## v1.0.0 Recovery
- 修正登入輸入值讀取相容性。
- 新增完整 JSON 備份與還原。
